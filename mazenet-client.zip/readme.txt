ausf�hren:

	ben�tigt: 	
	- vc++ 2010 32bit redistr.
	- xerces dll (mitgeliefert)

	befehl:
	mazenet-client <hostname> <port>
	z.B.
	mazenet-client localhost 5123
	
kompilieren:
	
	ben�tigt:
	- c++11
	- boost c++ libraries (mindestens asio und system)
	- CodeSynthesis XSD (f�r header und import lib, generierte header mitgeliefert)
	
team:
	Daniel Abele